package com.company;

class Node {
    int data;
    Node next;

    Node(int d) {
        data = d;
        next = null;
    }
}

class LinkedList {
    Node head;

    public static void main(String[] args) {
        LinkedList llist = new LinkedList();

        llist.push(6);
        llist.push(3);
        llist.push(8);
        llist.push(1);
        llist.push(9);
        llist.push(2);
        llist.push(5);

        System.out.print("Lista inainte de ordonare este: \n");
        llist.printList();

        llist.schimbaNod(2, 6);

        System.out.print("\nLista dupa ordonare este: \n");
        llist.printList();
    }

    public void schimbaNod(int a, int b) {

        if (a == b) return;


        Node before_a = null, current_a = head;
        while (current_a != null && current_a.data != a) {
            before_a = current_a;
            current_a = current_a.next;
        }


        Node before_b = null, current_b = head;
        while (current_b != null && current_b.data != b) {
            before_b = current_b;
            current_b = current_b.next;
        }


        if (current_a == null || current_b == null)
            return;


        if (before_a != null)
            before_a.next = current_b;
        else
            head = current_b;


        if (before_b != null)
            before_b.next = current_a;
        else
            head = current_a;

        Node temp = current_a.next;
        current_a.next = current_b.next;
        current_b.next = temp;
    }

    public void push(int new_data) {
        Node new_Node = new Node(new_data);

        new_Node.next = head;

        head = new_Node;
    }

    public void printList() {
        Node node = head;
        while (node != null) {
            System.out.print(node.data + " ");
            node = node.next;
        }
    }
} 