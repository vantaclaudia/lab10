package com.company;


class Polinom {
    private int[] coeficient;
    private int dgr;

  
    public Polinom(int a, int b) {
        if (b < 0) {
            throw new IllegalArgumentException("Exponentul nu poate fi negativ: " + b);
        }
        coeficient = new int[b+1];
        coeficient[b] = a;
        reduce();
    }

  
    private void reduce() {
        dgr = -1;
        for (int i = coeficient.length - 1; i >= 0; i--) {
            if (coeficient[i] != 0) {
                dgr = i;
                return;
            }
        }
    }

   
    public int degree() {
        return dgr;
    }

  
    public Polinom plus(Polinom that) {
        Polinom poly = new Polinom(0, Math.max(this.dgr, that.dgr));
        for (int i = 0; i <= this.dgr; i++) poly.coeficient[i] += this.coeficient[i];
        for (int i = 0; i <= that.dgr; i++) poly.coeficient[i] += that.coeficient[i];
        poly.reduce();
        return poly;
    }

  
    public Polinom minus(Polinom that) {
        Polinom poly = new Polinom(0, Math.max(this.dgr, that.dgr));
        for (int i = 0; i <= this.dgr; i++) poly.coeficient[i] += this.coeficient[i];
        for (int i = 0; i <= that.dgr; i++) poly.coeficient[i] -= that.coeficient[i];
        poly.reduce();
        return poly;
    }

  
    public Polinom times(Polinom that) {
        Polinom poly = new Polinom(0, this.dgr + that.dgr);
        for (int i = 0; i <= this.dgr; i++)
            for (int j = 0; j <= that.dgr; j++)
                poly.coeficient[i+j] += (this.coeficient[i] * that.coeficient[j]);
        poly.reduce();
        return poly;
    }


    public boolean equals(Object other) {
        if (other == this) return true;
        if (other == null) return false;
        if (other.getClass() != this.getClass()) return false;
        Polinom that = (Polinom) other;
        if (this.dgr != that.dgr) return false;
        for (int i = this.dgr; i >= 0; i--)
            if (this.coeficient[i] != that.coeficient[i]) return false;
        return true;
    }


   
    public int evaluate(int x) {
        int p = 0;
        for (int i = dgr; i >= 0; i--)
            p = coeficient[i] + (x * p);
        return p;
    }

  
    public int compareTo(Polinom that) {
        if (this.dgr < that.dgr) return -1;
        if (this.dgr > that.dgr) return +1;
        for (int i = this.dgr; i >= 0; i--) {
            if (this.coeficient[i] < that.coeficient[i]) return -1;
            if (this.coeficient[i] > that.coeficient[i]) return +1;
        }
        return 0;
    }


    public String toString() {
        if      (dgr == -1) return "0";
        else if (dgr ==  0) return "" + coeficient[0];
        else if (dgr ==  1) return coeficient[1] + "x + " + coeficient[0];
        String s = coeficient[dgr] + "x^" + dgr;
        for (int i = dgr - 1; i >= 0; i--) {
            if      (coeficient[i] == 0) continue;
            else if (coeficient[i]  > 0) s = s + " + " + (coeficient[i]);
            else if (coeficient[i]  < 0) s = s + " - " + (-coeficient[i]);
            if      (i == 1) s = s + "x";
            else if (i >  1) s = s + "x^" + i;
        }
        return s;
    }

   
    public static void main(String[] args) {
        Polinom zero = new Polinom(0, 0);

        Polinom p1 = new Polinom(5, 1);
        Polinom p2 = new Polinom(2, 3);
        Polinom p3 = new Polinom(3, 2);
        Polinom p4 = new Polinom(1, 5);
        Polinom p  = p1.plus(p2).plus(p3).plus(p4);

        Polinom q1   = new Polinom(2, 4);
        Polinom q2   = new Polinom(3, 2);
        Polinom q    = q1.plus(q2);


        Polinom r = p.plus(q);
        Polinom s = p.times(q);


        System.out.println("p(x) = " + p);
        System.out.println("q(x) = " + q);
        System.out.println("p(x) + q(x)= " + r);
        System.out.println("p(x) * q(x)= " + s);
    }
}
