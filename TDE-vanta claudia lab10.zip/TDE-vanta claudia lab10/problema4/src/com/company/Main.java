package com.company;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

class Student {
    private String nume;
    private double nota;
    private int option;


    public Student(String nume, double nota, int option) {
        this.nume = nume;
        this.nota = nota;
        this.option = option;

    }

    public static void main(String[] args) {
        LinkedList<Student> st = new LinkedList<>();
        LinkedList<Student> M = new LinkedList<>();
        LinkedList<Student> F = new LinkedList<>();
        LinkedList<Student> B = new LinkedList<>();
        int b = 0;
        int f = 0;
        int m = 0;
        st.add(new Student("Mihai", 9.31, 1));
        st.add(new Student("Maya", 5.23, 3));
        st.add(new Student("Ioana", 8.23, 1));
        st.add(new Student("Diana", 8.19, 2));
        st.add(new Student("Ana", 3.12, 2));
        st.add(new Student("Claudia", 8.13, 2));
        for (int i = 0; i < st.size(); i++) {
            if (st.get(i).getOption() == 1)
                M.add(st.get(i));
            if (st.get(i).getOption() == 2)
                F.add(st.get(i));
            if (st.get(i).getOption() == 3)
                B.add(st.get(i));
        }
        Collections.sort(M, new sortareNota());
        Collections.sort(F, new sortareNota());
        Collections.sort(B, new sortareNota());
        System.out.println("\nStudenti la matematica:" +
                "\nindex    value");
        for (int i = 0; i < M.size(); i++)
            System.out.println(M.get(i));
        System.out.println("\nStudenti la filologie:" +
                "\nindex    value");
        for (int i = 0; i < F.size(); i++)
            System.out.println(F.get(i));
        System.out.println("\nStudenti la biologie:" +
                "\nindex         value");
        for (int i = 0; i < B.size(); i++)
            System.out.println(B.get(i));


    }

    public String getName() {
        return nume;
    }

    public void setName(String name) {
        this.nume = name;
    }

    public double getGrade() {
        return nota;
    }

    public void setGrade(float grade) {
        this.nota = grade;
    }

    public int getOption() {
        return option;
    }

    public void setOption(int option) {
        this.option = option;
    }

    public String toString() {
        return this.nume + "          " + this.nota;
    }

    static class sortareNota implements Comparator<Student> {
        public int compare(Student a, Student b) {
            return (int) (b.getGrade() * 100 - a.getGrade() * 100);
        }
    }
}
