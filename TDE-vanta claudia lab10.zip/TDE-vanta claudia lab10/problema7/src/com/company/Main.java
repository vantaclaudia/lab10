package com.company;

import java.util.*;
import java.lang.*;

class Number {
    int rollNo;
    String val;

    public Number(int rollNo, String val) {
        this.rollNo = rollNo;
        this.val = val;
    }

    public void getRollno(int rollno) {
        this.rollNo = rollno;
    }

    public void getVal(String val) {
        this.val = val;
    }

    public String toString() {
        return this.rollNo + "          " + this.val;
    }
}

class Sortbyval implements Comparator<Number> {
    public int compare(Number a, Number b) {
        return a.val.compareTo(b.val);
    }
}

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;

        LinkedList<Number> ar = new LinkedList<>();
        for (int i = 0; i < 5; i++) {
            System.out.println("Cuvantul " + i + " este: ");
            ar.add(new Number(i, sc.nextLine()));
        }

        System.out.println("Cuvintele nesortate sunt: ");
        for (int i = 0; i < 5; i++)
            System.out.println(ar.get(i));

        Collections.sort(ar, new Sortbyval());

        System.out.println("\nCuvintele sortate sunt: " +
                "\nindex      cuvinte");
        for (int i = 0; i < 5; i++)
            System.out.println(ar.get(i));
    }
} 