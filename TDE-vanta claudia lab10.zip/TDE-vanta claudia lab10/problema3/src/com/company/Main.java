package com.company;

import java.util.*;
import java.lang.*;

class Number {
    int rollno;
    int val;

    public Number(int rollno, int val) {
        this.rollno = rollno;
        this.val = val;
    }

    public void getRollno(int rollno) {
        this.rollno = rollno;
    }

    public void getVal(int val) {
        this.val = val;
    }

    public String toString() {
        return this.rollno + "            " + this.val;
    }
}

class sortByValMain implements Comparator<Number> {
    public int compare(Number a, Number b) {
        return a.val - b.val;
    }
}

class sortByVal implements Comparator<Number> {
    public int compare(Number a, Number b) {
        return b.val - a.val;
    }
}

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        int i = 0;
        boolean True = true;
        LinkedList<Number> ar = new LinkedList<>();

        ar.add(new Number(i, 6));
        ar.add(new Number(++i, 5));
        ar.add(new Number(++i, 3));
        ar.add(new Number(++i, 9));
        ar.add(new Number(++i, 1));
        ar.add(new Number(++i, 7));


        System.out.println(
                        "- A - Vizualizeaza lista \n" +
                        "- B - Sterge un element  \n" +
                        "- C - Adauga un element  \n");

        while (True) {
            System.out.print("Alegeti meniul dorit (A,B sau C): ");
            String c = sc.nextLine();
            String d = c.toLowerCase();
            switch (d) {

                case "a":
                    LinkedList<Number> par = new LinkedList<>();
                    LinkedList<Number> impar = new LinkedList<>();
                    LinkedList<Number> updated = new LinkedList<>();
                    System.out.println("Lista sortata este:" + "\nIndexul    Valoarea\"");
                    for (int j = 0; j < ar.size(); j++) {
                        if (j % 2 == 0) {
                            par.add(ar.get(j));
                        } else {
                            impar.add(ar.get(j));
                        }
                    }
                    Collections.sort(par, new sortByValMain());
                    Collections.sort(impar, new sortByVal());
                    for (int j = 0; j < par.size(); j++)
                        updated.add(par.get(j));
                    for (int j = par.size(); j < ar.size(); j++)
                        updated.add(impar.get(j - par.size()));

                    for (int j = 0; j < updated.size(); j++)
                        System.out.println(updated.get(j));
                    break;
                case "b":
                    System.out.println("Introduceti pozitia numarului: ");
                    n = sc.nextInt();
                    ar.remove(n);
                    break;
                case "c":
                    System.out.println("Introduceti numarul dorit: ");
                    n = sc.nextInt();
                    ar.add(new Number(++i, n));
                    break;


            }

        }
    }
}

