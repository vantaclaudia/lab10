package com.company;

import java.util.Collections;
import java.util.Scanner;

import static com.company.Nod.BinarySearch.binarySearch;

class Nod {
    private static Nod head;
    private int value;
    private Nod next;


    public Nod(int value) {
        this.value = value;
    }

    public Nod getHead() {
        return head;
    }

    public void setHead(Nod head) {
        this.head = head;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Nod getNext() {
        return next;
    }

    public void setNext(Nod next) {
        this.next = next;
    }

    static class BinarySearch {
        static Nod push(Nod head, int data) {
            Nod newNode = new Nod(data);
            newNode.next = head;
            head = newNode;
            return head;
        }

        static Nod middleNode(Nod start, Nod last) {
            if (start == null)
                return null;

            Nod slow = start;
            Nod fast = start.next;

            while (fast != last) {
                fast = fast.next;
                if (fast != last) {
                    slow = slow.next;
                    fast = fast.next;
                }
            }
            return slow;
        }

        static Nod binarySearch(Nod head, int value) {
            Nod start = head;
            Nod last = null;

            do {
                Nod mid = middleNode(start, last);

                if (mid == null)
                    return null;

                if (mid.value == value)
                    return mid;

                else if (mid.value > value) {
                    start = mid.next;
                } else
                    last = mid;
            } while (last == null || last != start);

            return null;
        }
    }
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduceti numere,cand terminati apasati 0: ");
        int n = 0;
        int s = scanner.nextInt();
        Nod head = null;
        Nod previous = null;

        while (s != 0) {
            n++;
            Nod actual = new Nod(s);
            actual.setHead(head);
            if (head == null) {
                head = actual;
            } else {
                previous.setNext(actual);
                actual.setHead(head);
            }

            previous = actual;
            s = scanner.nextInt();
        }

        print(previous.getHead());
        System.out.println("Alegeti un element pe care doriti sa il stergeti");
        int d = scanner.nextInt();
        deleteNode(d);

        print(previous.getHead());
        System.out.println("Lista in ordine inversa este: ");

        printrev(head.getHead());
        System.out.println("Verificati daca exista valoarea aleasa: ");
        int val = scanner.nextInt();
        if (BinarySearch.binarySearch(head, val) == null)
            System.out.println("Nu am gasit valoarea aleasa! ");
        else
            System.out.println("Am gasit valoarea aleasa! ");
    }

    static void print(Nod a) {
        while (a != null) {
            System.out.println(a.getValue());
            a = a.getNext();
        }
    }

    static void printrev(Nod head) {
        Nod current = head;
        Nod last = null;

        while (last != head) {

            while (current.next != last) {
                current = current.next;
            }

            last = current;
            System.out.println(last.value);

            current = head;
        }
    }

    static void deleteNode(int position) {
        if (head == null)
            return;

        Nod temp = head;

        if (position == 0) {
            head = temp.next;
            return;
        }

        for (int i = 0; temp != null && i < position - 1; i++)
            temp = temp.next;

        if (temp == null || temp.next == null)
            return;

        Nod next = temp.next.next;

        temp.next = next;
    }
}

