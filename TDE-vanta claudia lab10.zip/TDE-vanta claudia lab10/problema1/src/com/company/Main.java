package com.company;

import java.util.*;
import java.lang.*;

class Number {
    int rollno;
    int val;

    public Number(int rollno, int val) {
        this.rollno = rollno;
        this.val = val;
    }

    public void getRollno(int rollno) {
        this.rollno = rollno;
    }

    public void getValue(int val) {
        this.val = val;
    }

    public String toString() {
        return this.rollno + "          " + this.val;
    }
}

class sortareValori implements Comparator<Number> {
        public int compare(Number a, Number b) {
        return a.val - b.val;
    }
}

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;

        LinkedList<Number> ar = new LinkedList<>();
        for (int i = 0; i < 10; i++) {
            System.out.println("Valoarea numarului " + i + " este: ");
            ar.add(new Number(i, sc.nextInt()));
        }

        System.out.println("Lista nesortata este: ");
        for (int i = 0; i < 10; i++)
            System.out.println(ar.get(i));

        Collections.sort(ar, new sortareValori());

        System.out.println("\nLista sortata dupa valoare:" +
                "\nindex    value");
        for (int i = 0; i < 10; i++)
            System.out.println(ar.get(i));
    }
} 