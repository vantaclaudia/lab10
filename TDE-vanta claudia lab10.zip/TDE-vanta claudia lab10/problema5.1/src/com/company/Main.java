package com.company;

import java.util.Collections;
import java.util.Scanner;

import static com.company.Node.BinarySearch.binarySearch;

class Node {
    private static Node head;
    private int value;
    private Node next;


    public Node(int value) {
        this.value = value;
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduceti numere, cand ati terminat apasati 0: \n");
        int n = 0;
        int s = scanner.nextInt();
        Node head = null;
        Node previous = null;

        while (s != 0) {
            n++;
            Node actual = new Node(s);
            actual.setHead(head);
            if (head == null) {
                head = actual;
            } else {
                previous.setNext(actual);
            }

            previous = actual;
            s = scanner.nextInt();
        }

        print(previous.getHead());
        System.out.println("Alegeti un element pe care doriti sa il stergeti: ");
        int d = scanner.nextInt();
        deleteNode(d);

        print(previous.getHead());
        System.out.println("Lista in ordine inversa este: ");

        printrev(head.getHead());
        System.out.println("Verificati daca exista valoarea: ");
        int val = scanner.nextInt();
        if (binarySearch(head, val) == null)
            System.out.println("Nu am gasit valoarea aleasa! ");
        else
            System.out.println("Am gasit valoarea aleasa! ");
    }

    static void print(Node a) {
        while (a != null) {
            System.out.println(a.getValue());
            a = a.getNext();
        }
    }

    static void printrev(Node head) {
        Node current = head;
        Node last = null;

        while (last != head) {

            while (current.next != last) {
                current = current.next;
            }

            last = current;
            System.out.println(last.value);

            current = head;
        }
    }

    static void deleteNode(int position) {
        if (head == null)
            return;

        Node temp = head;

        if (position == 0) {
            head = temp.next;
            return;
        }

        for (int i = 0; temp != null && i < position - 1; i++)
            temp = temp.next;

        if (temp == null || temp.next == null)
            return;

        Node next = temp.next.next;

        temp.next = next;
    }

    public Node getHead() {
        return head;
    }

    public void setHead(Node head) {
        this.head = head;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Node getNext() {
        return next;
    }

    public void setNext(Node next) {
        this.next = next;
    }

    static class BinarySearch {
        static Node push(Node head, int data) {
            Node newNode = new Node(data);
            newNode.next = head;
            head = newNode;
            return head;
        }

        static Node middleNode(Node start, Node last) {
            if (start == null)
                return null;

            Node s = start;
            Node f = start.next;

            while (f != last) {
                f = f.next;
                if (f != last) {
                    s = s.next;
                    f = f.next;
                }
            }
            return s;
        }

        static Node binarySearch(Node head, int value) {
            Node start = head;
            Node last = null;

            do {
                Node mid = middleNode(start, last);

                if (mid == null)
                    return null;

                if (mid.value == value)
                    return mid;

                else if (mid.value > value) {
                    start = mid.next;
                } else
                    last = mid;
            } while (last == null || last != start);

            return null;
        }
    }
}

